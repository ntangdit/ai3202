#Assignment 8 by Nikolai Tangdit
#Collaborated with Prad Kikkeri
import sys
import math

class HMM(object):
	def __init__(self, data):
		#The array of tuples is data
		self.data= data
		self.letterEm= {}
		self.letterTr= {}
		self.letterInit= {}
		#Create a table for each letter
		#Tables will be emission, transition, and initial probability
		for k in range(97, 123):
			self.letterEm[chr(k)]= {}
			self.letterTr[chr(k)]= {}
			self.letterInit[chr(k)]= {0.038}
			#0.038 comes from 1/26, since I don't have a marginal value
			
	def probs(self, letter):
		s= 0.0
		OgvS= {}
		nexter= {}
		
		for m in range(0, len(self.data)-1):
			if self.data[m][0] is letter:
				s +=1
				#Protect from indexing outside of array
				try:
					if self.data[m+1][0] in nexter.keys():
						nexter[self.data[m+1][0]] += 1
					else:
						nexter[self.data[m+1][0]] = 1
				except IndexError:
					pass
				if self.letterEm[letter].has_key(self.data[m][1]):
					OgvS[self.data[m][1]] += 1
				else:
					OgvS[self.data[m][1]] = 1
					
		for key, val in nexter.items():
			self.letterTr[letter][key]= round((val+1)/(s+26), 3)
		for key, val in OgvS.items():
			self.letterEm[letter][key]= round((val+1)/(s+8),3)
		
		self.letterInit[letter]= round(s/len(self.data),3)

		
	def printer(self):
		print "For Emission Probabilities:\n\n"
		results = []
		for k in self.letterEm.keys():
			for ns, value in self.letterEm[k].items():
				strn = "P("+ns+"|"+k+") = " + str(value)
				results.append(strn)
		for m in sorted(results):
			print m
		print "\n\n For Transition Probabilities:\n\n"
		results = []
		for k in self.letterTr.keys():
			for ns, value in self.letterTr[k].items():
				strn = "P("+ns+"|"+k+") = " + str(value)
				results.append(strn)
		for m in sorted(results):
			print m
		
		print "\n\nMarginal Values: \n\n"
		for k in self.letterInit.keys():
			print "initial marginal for", k+":", self.letterInit[k]
 





if __name__ == '__main__':
	filename= 'typos20.data'
	typos= open(filename, 'r')
	dataR= []
	#Put all information into a array with tuples
	file= typos.readlines()
	for line in file:
		if line[0] is not '_':
			dataR.append((line[0], line[2]))
	markov= HMM(dataR)
	for letter in markov.letterEm.keys():
		markov.probs(letter)
	print markov.letterTr['c']['k']
	sys.stdout = open('output.txt', 'w')
	markov.printer()